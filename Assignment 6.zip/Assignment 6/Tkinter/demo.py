from tkinter import *

window = Tk()
window.geometry("300x400")
window.title("Simple Calculator")

e = Entry(window, width=28, borderwidth=5)
e.place(x=20, y=20)

i = 0
operator = ""

def click(num):
    current = e.get()
    e.delete(0, END)
    e.insert(0, str(current) + str(num))

def clear():
    e.delete(0, END)

def add():
    global i, operator
    i = int(e.get())
    operator = "+"
    e.delete(0, END)

def sub():
    global i, operator
    i = int(e.get())
    operator = "-"
    e.delete(0, END)

def mult():
    global i, operator
    i = int(e.get())
    operator = "*"
    e.delete(0, END)

def div():
    global i, operator
    i = int(e.get())
    operator = "/"
    e.delete(0, END)

def equal():
    second = int(e.get())
    e.delete(0, END)
    if operator == "+":
        e.insert(0, i + second)
    elif operator == "-":
        e.insert(0, i - second)
    elif operator == "*":
        e.insert(0, i * second)
    elif operator == "/":
        try:
            e.insert(0, i / second)
        except ZeroDivisionError:
            e.insert(0, "Error")


Button(window, text="1", width=12, command=lambda: click(1)).place(x=10, y=60)
Button(window, text="2", width=12, command=lambda: click(2)).place(x=100, y=60)
Button(window, text="3", width=12, command=lambda: click(3)).place(x=190, y=60)

Button(window, text="4", width=12, command=lambda: click(4)).place(x=10, y=100)
Button(window, text="5", width=12, command=lambda: click(5)).place(x=100, y=100)
Button(window, text="6", width=12, command=lambda: click(6)).place(x=190, y=100)

Button(window, text="7", width=12, command=lambda: click(7)).place(x=10, y=140)
Button(window, text="8", width=12, command=lambda: click(8)).place(x=100, y=140)
Button(window, text="9", width=12, command=lambda: click(9)).place(x=190, y=140)

Button(window, text="0", width=12, command=lambda: click(0)).place(x=10, y=180)
Button(window, text="+", width=12, command=add).place(x=100, y=180)
Button(window, text="-", width=12, command=sub).place(x=190, y=180)

Button(window, text="*", width=12, command=mult).place(x=10, y=220)
Button(window, text="/", width=12, command=div).place(x=100, y=220)
Button(window, text="=", width=12, command=equal).place(x=190, y=220)

Button(window, text="Clear", width=39, command=clear).place(x=10, y=260)

window.mainloop()

