#Create list of numbers from 1 to 10
numbers = list(range(1, 11))
print("Original list:", numbers)

#Extract first 5 elements
first_five = numbers[:5]
print("Extracted first five elements:", first_five)

# Reverse extracted elements
reversed_five = first_five[::-1]
print("Reversed extracted elements:", reversed_five)
