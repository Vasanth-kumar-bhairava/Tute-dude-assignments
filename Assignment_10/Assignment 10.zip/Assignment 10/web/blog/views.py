from django.shortcuts import render, get_object_or_404
from blog.models import Post

def allpost(request):
    post = Post.objects.all().order_by('-created_at')  # Show latest posts first
    return render(request, 'post.html', {'post': post})

def details(request, blog_id):
    details = get_object_or_404(Post, pk=blog_id)  # Correct way to fetch post by ID
    return render(request, 'details.html', {'post': details})

