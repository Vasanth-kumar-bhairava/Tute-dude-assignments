from django.db import models

# Create your models here.

class Post(models.Model):
    title=models.CharField(max_length=200)
    public_date=models.DateTimeField()
    image=models.ImageField(upload_to='images/')
    body=models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)


    def summary(self):
        return self.body[:100]
    
    def pub_date(self):
        return self.public_date.strftime('%b %e,%y')
    
    def __str__(self):
        return self.title
    