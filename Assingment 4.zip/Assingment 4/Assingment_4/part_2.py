# Task 2: Writing and appending data to a file

filename = "output.txt"

# Write to file
text_to_write = input("Enter text to write to the file: ")
with open(filename, 'w') as file:
    file.write(text_to_write + '\n')
print("Data successfully written to output.txt.")


# Append to file
text_to_append = input("Enter additional text to append: ")
with open(filename, 'a') as file:
    file.write(text_to_append + '\n')
print("Data successfully appended.")



# Read final content
print("\nFinal content of output.txt:")
with open(filename, 'r') as file:
    print(file.read())

