
#  Part 1: Open and read sample.txt

with open("sample.txt", "r") as file:
    content = file.read()
    print(content)



# Part 2: Print each line with its line number

with open("sample.txt", "r") as file:
    lines = file.readlines()
    for i, line in enumerate(lines, 1):
        print(f"Line {i}: {line.strip()}")




# Part 3: Handle file not found error

filename = "sample.txt"

try:
    print("Reading file content:")
    with open(filename, "r") as file:
        lines = file.readlines()
        for i, line in enumerate(lines, 1):
            print(f"Line {i}: {line.strip()}")
except FileNotFoundError:
    print(f"Error: The file '{filename}' was not found.")
