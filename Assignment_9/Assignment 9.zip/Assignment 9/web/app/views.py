from django.shortcuts import render
from app.forms import ContactForm

# Create your views here.

from django.shortcuts import render
from app.forms import ContactForm

def index(request):
    if request.method == "POST":
        con = ContactForm(request.POST)
        if con.is_valid():
            con.save()
            return render(request, 'simple.html')  # or any success page
    else:
        con = ContactForm()
    return render(request, 'index.html', {'form': con})
