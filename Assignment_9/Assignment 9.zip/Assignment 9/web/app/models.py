from django.db import models

# Create your models here.
class contact(models.Model):
    first_name=models.CharField(max_length=200)
    last_name=models.CharField(max_length=200)
    email=models.EmailField()
    content=models.TextField(max_length=300)

    
    def __str__(self):
        return f"{self.first_name} {self.last_name}"

